---
title: "Mental, Emotional, and Spiritual Tylenol"
date: 2020-03-28
layout: post
category: prose
---

Your prescriptions's ready for pickup:

Mental Tylenol: Do something for another.

Emotional Tylenol:  Help another.

Spiritual Tylenol:  Realize there are no 'others'.

PRN (Take as needed): Surrender.
